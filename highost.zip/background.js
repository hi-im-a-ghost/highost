chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.action === 'status') {
    chrome.declarativeNetRequest.getEnabledRulesets((rulesets) => {
      sendResponse({ enabled: rulesets.includes('ruleset_ads') })
    })
    return true
  }
  if (msg.action === 'toggle') {
    chrome.declarativeNetRequest.getEnabledRulesets((rulesets) => {
      const enabled = rulesets.includes('ruleset_ads')
      if (enabled) {
        chrome.declarativeNetRequest.updateEnabledRulesets({ disableRulesetIds: ['ruleset_ads'] }, () => sendResponse({ enabled: false }))
      } else {
        chrome.declarativeNetRequest.updateEnabledRulesets({ enableRulesetIds: ['ruleset_ads'] }, () => sendResponse({ enabled: true }))
      }
    })
    return true
  }
})
