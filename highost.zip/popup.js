const orb = document.getElementById('orb')
const statusEl = document.getElementById('status')
const statT = document.getElementById('stat-t')
const statE = document.getElementById('stat-e')

function setEnabled(val) {
  orb.classList.toggle('enabled', val)
  orb.classList.toggle('disabled', !val)
  statusEl.textContent = val ? 'Activado' : 'Desactivado'
  statT.textContent = val ? 'Bloqueados' : '—'
  statE.textContent = val ? 'Activo' : 'Inactivo'
}

chrome.runtime.sendMessage({ action: 'status' }, (res) => {
  setEnabled(res.enabled)
})

orb.addEventListener('click', () => {
  orb.classList.add('loading')
  orb.disabled = true
  chrome.runtime.sendMessage({ action: 'toggle' }, (res) => {
    setEnabled(res.enabled)
    orb.classList.remove('loading')
    orb.disabled = false
  })
})
